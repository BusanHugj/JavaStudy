package question;

public class questionBean {
	private int q_no;
	private int q_correct;
	private int q_incorrect;
	private String q_title;
	private String q_explain;
	private String q_fname;
	private String q_answer;
	private int q_right;
	private String cla_name;
	private String subject_subject_name;
	private double percent;
	private String a1;	
	private String a2;	
	private String a3;	
	private String a4;	
	
	
	
	public String getA1() {
		return a1;
	}
	public void setA1(String a1) {
		this.a1 = a1;
	}
	public String getA2() {
		return a2;
	}
	public void setA2(String a2) {
		this.a2 = a2;
	}
	public String getA3() {
		return a3;
	}
	public void setA3(String a3) {
		this.a3 = a3;
	}
	public String getA4() {
		return a4;
	}
	public void setA4(String a4) {
		this.a4 = a4;
	}
	public String getQ_title() {
		return q_title;
	}
	public void setQ_title(String q_title) {
		this.q_title = q_title;
	}
	public String getQ_explain() {
		return q_explain;
	}
	public void setQ_explain(String q_explain) {
		this.q_explain = q_explain;
	}
	public double getPercent() {
		return percent;
	}
	public void setPercent(double percent) {
		this.percent = percent;
	}
	
	public String getQ_fname() {
		return q_fname;
	}
	public void setQ_fname(String q_fname) {
		this.q_fname = q_fname;
	}
	public String getSubject_subject_name() {
		return subject_subject_name;
	}
	public void setSubject_subject_name(String subject_subject_name) {
		this.subject_subject_name = subject_subject_name;
	}
	public int getQ_no() {
		return q_no;
	}
	public void setQ_no(int q_no) {
		this.q_no = q_no;
	}
	public int getQ_correct() {
		return q_correct;
	}
	public void setQ_correct(int q_correct) {
		this.q_correct = q_correct;
	}
	public int getQ_incorrect() {
		return q_incorrect;
	}
	public void setQ_incorrect(int q_incorrect) {
		this.q_incorrect = q_incorrect;
	}
	public String getQ_answer() {
		return q_answer;
	}
	public void setQ_answer(String q_answer) {
		this.q_answer = q_answer;
	}
	public int getQ_right() {
		return q_right;
	}
	public void setQ_right(int q_right) {
		this.q_right = q_right;
	}
	public String getCla_name() {
		return cla_name;
	}
	public void setCla_name(String cla_name) {
		this.cla_name = cla_name;
	}
}
