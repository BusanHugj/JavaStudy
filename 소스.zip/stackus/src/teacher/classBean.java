package teacher;

public class classBean {
	private int cla_no;
	private String cla_name;
	private String cla_intro;
	private String subject_subject_name;
	private String member_mem_id;
	private int mem_type;
	private int cla_point;
	
	public int getCla_point() {
		return cla_point;
	}
	public void setCla_point(int cla_point) {
		this.cla_point = cla_point;
	}
	public int getCla_no() {
		return cla_no;
	}
	public void setCla_no(int cla_no) {
		this.cla_no = cla_no;
	}
	public String getCla_name() {
		return cla_name;
	}
	public void setCla_name(String cla_name) {
		this.cla_name = cla_name;
	}
	public String getCla_intro() {
		return cla_intro;
	}
	public void setCla_intro(String cla_intro) {
		this.cla_intro = cla_intro;
	}
	public String getSubject_subject_name() {
		return subject_subject_name;
	}
	public void setSubject_subject_name(String subject_subject_name) {
		this.subject_subject_name = subject_subject_name;
	}
	public String getMember_mem_id() {
		return member_mem_id;
	}
	public void setMember_mem_id(String member_mem_id) {
		this.member_mem_id = member_mem_id;
	}
	public int getMem_type() {
		return mem_type;
	}
	public void setMem_type(int mem_type) {
		this.mem_type = mem_type;
	}
	
	
	
	
}
