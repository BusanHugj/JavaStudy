package reservation;

import java.util.Date;

public class resBean {
	private String EX_NAME;
	private String RES_DATE;
	private String MEM_ID;
	public String getEX_NAME() {
		return EX_NAME;
	}
	public void setEX_NAME(String eX_NAME) {
		EX_NAME = eX_NAME;
	}
	public String getRES_DATE() {
		return RES_DATE;
	}
	public void setRES_DATE(String rES_DATE) {
		RES_DATE = rES_DATE;
	}
	public String getMEM_ID() {
		return MEM_ID;
	}
	public void setMEM_ID(String mEM_ID) {
		MEM_ID = mEM_ID;
	}
	
	
}
