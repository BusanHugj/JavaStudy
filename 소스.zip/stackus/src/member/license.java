package member;

public class license {
	private String mem_id;
	private String license_name;
	private int license_code;
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getLicense_name() {
		return license_name;
	}
	public void setLicense_name(String license_name) {
		this.license_name = license_name;
	}
	public int getLicense_code() {
		return license_code;
	}
	public void setLicense_code(int license_code) {
		this.license_code = license_code;
	}
	
	
}
