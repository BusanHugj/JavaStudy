package exam;

public class exambean {
	private String ex_object1;
	private String ex_object2;
	private int ex_code;
	private int ex_no;
	private String ex_content;
	private String ex_image;
	private String ex_first;
	private String ex_second;
	private String ex_third;
	private String ex_fourth;
	private String ex_fifth;
	private int ex_right;
	private String ex_comment;
	private int ex_correct;
	private int ex_incorrect;
	private int score;
	
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	public String getEx_comment() {
		return ex_comment;
	}
	public void setEx_comment(String ex_comment) {
		this.ex_comment = ex_comment;
	}
	public String getEx_object1() {
		return ex_object1;
	}
	public void setEx_object1(String ex_object1) {
		this.ex_object1 = ex_object1;
	}
	public String getEx_object2() {
		return ex_object2;
	}
	public void setEx_object2(String ex_object2) {
		this.ex_object2 = ex_object2;
	}
	public int getEx_code() {
		return ex_code;
	}
	public void setEx_code(int ex_code) {
		this.ex_code = ex_code;
	}
	public int getEx_no() {
		return ex_no;
	}
	public void setEx_no(int ex_no) {
		this.ex_no = ex_no;
	}
	public String getEx_content() {
		return ex_content;
	}
	public void setEx_content(String ex_content) {
		this.ex_content = ex_content;
	}
	public String getEx_image() {
		return ex_image;
	}
	public void setEx_image(String ex_image) {
		this.ex_image = ex_image;
	}
	public String getEx_first() {
		return ex_first;
	}
	public void setEx_first(String ex_first) {
		this.ex_first = ex_first;
	}
	public String getEx_second() {
		return ex_second;
	}
	public void setEx_second(String ex_second) {
		this.ex_second = ex_second;
	}
	public String getEx_third() {
		return ex_third;
	}
	public void setEx_third(String ex_third) {
		this.ex_third = ex_third;
	}
	public String getEx_fourth() {
		return ex_fourth;
	}
	public void setEx_fourth(String ex_fourth) {
		this.ex_fourth = ex_fourth;
	}
	public String getEx_fifth() {
		return ex_fifth;
	}
	public void setEx_fifth(String ex_fifth) {
		this.ex_fifth = ex_fifth;
	}
	public int getEx_right() {
		return ex_right;
	}
	public void setEx_right(int ex_right) {
		this.ex_right = ex_right;
	}
	public int getEx_correct() {
		return ex_correct;
	}
	public void setEx_correct(int ex_correct) {
		this.ex_correct = ex_correct;
	}
	public int getEx_incorrect() {
		return ex_incorrect;
	}
	public void setEx_incorrect(int ex_incorrect) {
		this.ex_incorrect = ex_incorrect;
	}
	
	
}
