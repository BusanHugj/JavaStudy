package my;

public class likeBean {
	private int BOARD_BO_NO;

	public int getBOARD_BO_NO() {
		return BOARD_BO_NO;
	}

	public void setBOARD_BO_NO(int bOARD_BO_NO) {
		BOARD_BO_NO = bOARD_BO_NO;
	}
	
	
}
